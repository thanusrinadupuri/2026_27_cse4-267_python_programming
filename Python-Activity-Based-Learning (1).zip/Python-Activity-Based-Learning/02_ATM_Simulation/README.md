# Case Study 2: ATM Simulation with Limits and Mini Statement

## Problem Statement
Simulate an ATM that verifies a PIN, allows balance enquiry, withdrawal and deposit with banking rules, and shows the last transactions.

## Objectives
- Validate PIN with a 3-attempt limit.
- Apply rules: multiples of 100, sufficient balance, daily limit.
- Maintain a transaction history list.

## Assumptions
- PIN is fixed as 1234; opening balance is Rs. 5000.
- Daily withdrawal limit is Rs. 20000.
- Only the last 5 transactions are shown.

## Algorithm
1. Ask PIN (max 3 attempts); block card if all fail.
2. Show menu and read choice.
3. Withdraw: validate amount, balance and daily limit, then update.
4. Deposit: validate amount, then update.
5. Record each successful transaction; repeat until Exit.

## Pseudocode
```
FOR attempt = 1 TO 3
    READ pin; IF pin = correct: BREAK
IF all failed: PRINT "Card blocked"; STOP
LOOP
    READ choice
    Withdraw: IF amt<=0 -> invalid
              ELSE IF amt MOD 100 != 0 -> multiple of 100
              ELSE IF amt > balance -> insufficient
              ELSE IF today + amt > 20000 -> limit exceeded
              ELSE balance = balance - amt, add to history
    Deposit : IF amt>0 balance = balance + amt, add to history
END LOOP
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[/Enter PIN/]
    B --> C{PIN correct?}
    C -- No, attempts left --> B
    C -- No, 3 failed --> X([Card blocked])
    C -- Yes --> D[/Menu choice/]
    D --> E{Choice}
    E -- Withdraw --> F{Rules satisfied?}
    F -- Yes --> G[Update balance and history]
    F -- No --> H[Show error]
    E -- Deposit --> I[Add amount]
    E -- Statement --> J[Print history]
    E -- Exit --> K([End])
    G --> D
    H --> D
    I --> D
    J --> D
```

## Source Code
See [atm.py](atm.py).

## Test Cases
| # | Input (balance, amount, withdrawn today) | Expected Output |
|---|-------------------|-----------------|
| 1 | 5000, 1000, 0 | (4000, Withdrawal successful) |
| 2 | 5000, 550, 0 | (5000, Amount must be a multiple of 100) |
| 3 | 500, 1000, 0 | (500, Insufficient balance) |
| 4 | 50000, 15000, 10000 | (50000, Daily limit exceeded) |
| 5 | 5000, -5, 0 | (5000, Invalid amount) |
| 6 | deposit(5000, 2000) | (7000, Deposit successful) |
| 7 | check_pin("1234","1234") | True |

## Output Screenshots
_Add screenshot here: `screenshots/02_output.png`_

## Conclusion
The ATM program applies multiple validation rules using conditions, loops and functions, and shows how real banking constraints can be coded simply.
