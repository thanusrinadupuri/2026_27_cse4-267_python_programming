"""Case Study 2: ATM Simulation with PIN check, limits and mini statement."""

DAILY_LIMIT = 20000


def check_pin(entered, correct):
    """Return True if the entered PIN matches."""
    return entered == correct


def withdraw(balance, amount, withdrawn_today):
    """Return (new_balance, message) after validating the withdrawal."""
    if amount <= 0:
        return balance, "Invalid amount"
    if amount % 100 != 0:
        return balance, "Amount must be a multiple of 100"
    if amount > balance:
        return balance, "Insufficient balance"
    if withdrawn_today + amount > DAILY_LIMIT:
        return balance, "Daily limit exceeded"
    return balance - amount, "Withdrawal successful"


def deposit(balance, amount):
    """Return (new_balance, message) after a deposit."""
    if amount <= 0:
        return balance, "Invalid amount"
    return balance + amount, "Deposit successful"


def main():
    correct_pin = "1234"
    balance = 5000
    withdrawn_today = 0
    history = []

    # Allow only 3 PIN attempts
    for attempt in range(3):
        if check_pin(input("Enter PIN: "), correct_pin):
            break
        print("Wrong PIN")
    else:
        print("Card blocked!")
        return

    while True:
        print("\n1.Balance 2.Withdraw 3.Deposit 4.Mini statement 5.Exit")
        choice = input("Choice: ")
        if choice == "1":
            print("Balance:", balance)
        elif choice == "2":
            amt = int(input("Amount: "))
            balance, msg = withdraw(balance, amt, withdrawn_today)
            if msg == "Withdrawal successful":
                withdrawn_today += amt
                history.append(f"Withdrew {amt}")
            print(msg)
        elif choice == "3":
            amt = int(input("Amount: "))
            balance, msg = deposit(balance, amt)
            if msg == "Deposit successful":
                history.append(f"Deposited {amt}")
            print(msg)
        elif choice == "4":
            for line in history[-5:]:
                print(line)
        elif choice == "5":
            break


if __name__ == "__main__":
    main()
