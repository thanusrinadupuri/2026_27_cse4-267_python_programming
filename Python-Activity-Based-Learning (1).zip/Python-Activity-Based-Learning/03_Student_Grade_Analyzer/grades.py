"""Case Study 3: Student Grade Analyzer with ranking and statistics."""


def get_grade(avg):
    """Convert an average mark into a grade letter."""
    if avg >= 90:
        return "O"
    elif avg >= 80:
        return "A"
    elif avg >= 70:
        return "B"
    elif avg >= 60:
        return "C"
    elif avg >= 50:
        return "D"
    return "F"


def analyse(students):
    """students: dict name -> list of marks.
    Returns list of (name, average, grade) sorted by average (highest first)."""
    result = []
    for name, marks in students.items():
        avg = sum(marks) / len(marks)
        result.append((name, round(avg, 2), get_grade(avg)))
    result.sort(key=lambda row: row[1], reverse=True)
    return result


def main():
    n = int(input("Number of students: "))
    s = int(input("Number of subjects: "))
    students = {}
    for _ in range(n):
        name = input("Student name: ")
        students[name] = [float(input(f"  Mark {i + 1}: ")) for i in range(s)]

    report = analyse(students)
    print("\nRank | Name | Average | Grade")
    for rank, (name, avg, grade) in enumerate(report, start=1):
        print(f"{rank:<4} | {name:<10} | {avg:<7} | {grade}")

    averages = [row[1] for row in report]
    print("Class average:", round(sum(averages) / len(averages), 2))
    print("Topper:", report[0][0])


if __name__ == "__main__":
    main()
