# Case Study 3: Student Grade Analyzer

## Problem Statement
A teacher needs a program that takes marks of several students, computes averages, assigns grades, ranks students and reports class statistics.

## Objectives
- Use dictionaries and lists for data.
- Compute average, grade and rank.
- Sort data using a key function.

## Assumptions
- Marks are between 0 and 100.
- Every student has the same number of subjects.
- Student names are unique.

## Algorithm
1. Read number of students and subjects.
2. For each student read name and marks.
3. Compute average and grade for each student.
4. Sort by average (descending) to get ranks.
5. Print the rank list, class average and topper.

## Pseudocode
```
READ n, s
FOR each student
    READ name, marks[1..s]
    avg = SUM(marks) / s
    grade = lookup(avg)
SORT students by avg descending
PRINT rank, name, avg, grade
PRINT class average, topper
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[/Read n and subjects/]
    B --> C[/Read name and marks of a student/]
    C --> D[Compute average and grade]
    D --> E{More students?}
    E -- Yes --> C
    E -- No --> F[Sort by average descending]
    F --> G[Print rank list, class average, topper]
    G --> H([End])
```

## Source Code
See [grades.py](grades.py).

## Test Cases
| # | Input | Expected Output |
|---|-------|-----------------|
| 1 | get_grade(95) | O |
| 2 | get_grade(80) | A |
| 3 | get_grade(65) | C |
| 4 | get_grade(49.9) | F |
| 5 | analyse({"Ravi":[80,90,100],"Sita":[60,70,50]}) | [("Ravi",90.0,"O"),("Sita",60.0,"C")] |

## Output Screenshots
_Add screenshot here: `screenshots/03_output.png`_

## Conclusion
The program automates result processing and demonstrates sorting, aggregation and conditional grading in Python.
