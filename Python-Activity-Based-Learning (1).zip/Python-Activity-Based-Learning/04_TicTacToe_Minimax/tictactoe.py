"""Case Study 4: Unbeatable Tic-Tac-Toe using the Minimax algorithm.
Board is a list of 9 cells: 'X', 'O' or ' '. Computer plays 'O'."""

WIN_LINES = [(0, 1, 2), (3, 4, 5), (6, 7, 8),
             (0, 3, 6), (1, 4, 7), (2, 5, 8),
             (0, 4, 8), (2, 4, 6)]


def winner(board):
    """Return 'X' or 'O' if someone has won, else None."""
    for a, b, c in WIN_LINES:
        if board[a] != " " and board[a] == board[b] == board[c]:
            return board[a]
    return None


def minimax(board, player, depth):
    """Score a position: +10 if O wins, -10 if X wins, 0 for draw.
    Subtracting depth makes the computer prefer quicker wins."""
    w = winner(board)
    if w == "O":
        return 10 - depth
    if w == "X":
        return depth - 10
    if " " not in board:
        return 0

    scores = []
    for i in range(9):
        if board[i] == " ":
            board[i] = player                       # try the move
            next_player = "X" if player == "O" else "O"
            scores.append(minimax(board, next_player, depth + 1))
            board[i] = " "                          # undo the move
    return max(scores) if player == "O" else min(scores)


def best_move(board):
    """Return the best cell index for the computer ('O')."""
    best_score, move = -100, None
    for i in range(9):
        if board[i] == " ":
            board[i] = "O"
            score = minimax(board, "X", 1)
            board[i] = " "
            if score > best_score:
                best_score, move = score, i
    return move


def show(board):
    for r in range(0, 9, 3):
        print(" | ".join(board[r:r + 3]))
        if r < 6:
            print("--+---+--")


def main():
    board = [" "] * 9
    print("You are X (cells 0-8). Computer is O.")
    while True:
        show(board)
        move = int(input("Your move (0-8): "))
        if move not in range(9) or board[move] != " ":
            print("Invalid move")
            continue
        board[move] = "X"
        if winner(board) or " " not in board:
            break
        board[best_move(board)] = "O"
        if winner(board) or " " not in board:
            break
    show(board)
    print(f"{winner(board)} wins!" if winner(board) else "It's a draw!")


if __name__ == "__main__":
    main()
