# Case Study 4: Unbeatable Tic-Tac-Toe using Minimax

## Problem Statement
Build a two-player Tic-Tac-Toe game where the computer never loses, by exploring all possible future moves.

## Objectives
- Represent a board using a list.
- Detect wins and draws.
- Apply recursion and the Minimax algorithm.

## Assumptions
- Human plays X and moves first; computer plays O.
- Cells are numbered 0 to 8, row by row.
- Invalid moves are rejected and re-asked.

## Algorithm
1. Draw the empty board; the human plays X.
2. After each human move, check for win/draw.
3. For the computer, try every empty cell, score it with Minimax (recursive), undo the move.
4. Choose the cell with the highest score.
5. Repeat until win or draw.

## Pseudocode
```
FUNCTION minimax(board, player, depth)
    IF O has won RETURN 10 - depth
    IF X has won RETURN depth - 10
    IF board full RETURN 0
    FOR each empty cell
        place player, score = minimax(board, other, depth+1), undo
    IF player = O RETURN MAX(scores) ELSE RETURN MIN(scores)

FUNCTION best_move(board)
    FOR each empty cell: try O, score = minimax(board, X, 1), undo
    RETURN cell with highest score
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Show board]
    B --> C[/Human enters move/]
    C --> D{Valid?}
    D -- No --> C
    D -- Yes --> E[Place X]
    E --> F{Win or draw?}
    F -- Yes --> Z[Print result]
    F -- No --> G[Computer finds best move via Minimax]
    G --> H[Place O]
    H --> I{Win or draw?}
    I -- No --> B
    I -- Yes --> Z
    Z --> J([End])
```

## Source Code
See [tictactoe.py](tictactoe.py).

## Test Cases
| # | Board (0-8), O to move | Expected best_move |
|---|------------------------|--------------------|
| 1 | O O _ / X X _ / _ _ _ | 2 (O wins immediately) |
| 2 | X X _ / O _ _ / _ _ _ | 2 (blocks X) |
| 3 | winner(X X X / _ _ _ / _ _ _) | X |
| 4 | winner(empty board) | None |
| 5 | Full game vs. computer | Never a win for human (draw or O wins) |

## Output Screenshots
_Add screenshot here: `screenshots/04_output.png`_

## Conclusion
Minimax makes the computer play perfectly. The program shows recursion, backtracking (try and undo) and game-tree search in a beginner-friendly way.
