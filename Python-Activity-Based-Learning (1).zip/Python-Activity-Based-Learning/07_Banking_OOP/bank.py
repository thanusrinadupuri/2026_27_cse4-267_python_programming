"""Case Study 7: Banking System using Classes, Inheritance and Exceptions."""


class InsufficientFundsError(Exception):
    """Raised when a withdrawal is more than the allowed balance."""


class Account:
    def __init__(self, acc_no, owner, balance=0):
        self.acc_no = acc_no
        self.owner = owner
        self.balance = balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("Deposit must be positive")
        self.balance += amount

    def withdraw(self, amount):
        if amount <= 0:
            raise ValueError("Withdrawal must be positive")
        if amount > self.balance:
            raise InsufficientFundsError("Not enough balance")
        self.balance -= amount

    def __str__(self):
        return f"{self.acc_no} | {self.owner} | Rs.{self.balance}"


class SavingsAccount(Account):
    """Savings account earns interest."""

    def __init__(self, acc_no, owner, balance=0, rate=4):
        super().__init__(acc_no, owner, balance)
        self.rate = rate

    def add_interest(self):
        self.balance += self.balance * self.rate / 100


class CurrentAccount(Account):
    """Current account allows an overdraft up to a limit."""

    def __init__(self, acc_no, owner, balance=0, overdraft=5000):
        super().__init__(acc_no, owner, balance)
        self.overdraft = overdraft

    def withdraw(self, amount):                     # overrides parent method
        if amount <= 0:
            raise ValueError("Withdrawal must be positive")
        if amount > self.balance + self.overdraft:
            raise InsufficientFundsError("Overdraft limit exceeded")
        self.balance -= amount


def transfer(source, target, amount):
    """Move money between two accounts."""
    source.withdraw(amount)
    target.deposit(amount)


def main():
    a = SavingsAccount(1, "Asha", 10000)
    b = CurrentAccount(2, "Bala", 1000)
    try:
        transfer(a, b, 3000)
        a.add_interest()
        print(a)
        print(b)
        transfer(b, a, 20000)                       # will fail
    except (InsufficientFundsError, ValueError) as err:
        print("Error:", err)


if __name__ == "__main__":
    main()
