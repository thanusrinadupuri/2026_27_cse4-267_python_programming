# Case Study 7: Banking System using OOP and Exception Handling

## Problem Statement
Model a bank with savings and current accounts that support deposit, withdrawal, interest, overdraft and transfers, while handling invalid operations safely.

## Objectives
- Use classes, objects, inheritance and method overriding.
- Create a custom exception.
- Handle errors with try / except.

## Assumptions
- Savings interest rate is 4% (single add on demand).
- Current account overdraft limit is Rs. 5000.
- All amounts are positive numbers.

## Algorithm
1. Define base class `Account` with deposit and withdraw.
2. Define `SavingsAccount` (interest) and `CurrentAccount` (overdraft, overrides withdraw).
3. Raise `ValueError` for non-positive amounts and `InsufficientFundsError` for over-withdrawal.
4. Transfer = withdraw from source, then deposit to target.
5. Catch exceptions in `main` and print a message.

## Pseudocode
```
CLASS Account: deposit(amt), withdraw(amt)
CLASS Savings EXTENDS Account: add_interest()
CLASS Current EXTENDS Account: withdraw(amt) allows balance + overdraft

FUNCTION transfer(src, dst, amt)
    src.withdraw(amt)
    dst.deposit(amt)

TRY transfer ... CATCH error: PRINT error
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Create Savings and Current accounts]
    B --> C[/Transfer amount/]
    C --> D{Amount > 0?}
    D -- No --> E[Raise ValueError]
    D -- Yes --> F{Amount within balance/overdraft?}
    F -- No --> G[Raise InsufficientFundsError]
    F -- Yes --> H[Withdraw from source, deposit to target]
    E --> I[Catch and print error]
    G --> I
    H --> J[Print balances]
    I --> K([End])
    J --> K
```

## Source Code
See [bank.py](bank.py).

## Test Cases
| # | Input | Expected Output |
|---|-------|-----------------|
| 1 | Savings(10000).withdraw(3000) | balance 7000 |
| 2 | Savings(1000).withdraw(5000) | InsufficientFundsError |
| 3 | Current(1000).withdraw(5500) | balance -4500 (overdraft) |
| 4 | Current(1000).withdraw(7000) | InsufficientFundsError |
| 5 | deposit(-50) | ValueError |
| 6 | Savings(10000, rate 4).add_interest() | balance 10400.0 |
| 7 | transfer(A 10000, B 1000, 3000) | A = 7000, B = 4000 |

## Output Screenshots
_Add screenshot here: `screenshots/07_output.png`_

## Conclusion
Inheritance avoids repeated code, overriding customises behaviour, and exceptions keep the program from crashing on bad input.
