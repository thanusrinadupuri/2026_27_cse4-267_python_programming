"""Case Study 9: Matrix Calculator (add, multiply, transpose, determinant)."""


def add(a, b):
    """Add two matrices of the same size."""
    if len(a) != len(b) or len(a[0]) != len(b[0]):
        raise ValueError("Matrices must be the same size")
    return [[a[i][j] + b[i][j] for j in range(len(a[0]))] for i in range(len(a))]


def multiply(a, b):
    """Multiply matrix a (m x n) by matrix b (n x p)."""
    if len(a[0]) != len(b):
        raise ValueError("Columns of A must equal rows of B")
    result = [[0] * len(b[0]) for _ in range(len(a))]
    for i in range(len(a)):
        for j in range(len(b[0])):
            for k in range(len(b)):
                result[i][j] += a[i][k] * b[k][j]
    return result


def transpose(a):
    """Swap rows and columns."""
    return [[a[i][j] for i in range(len(a))] for j in range(len(a[0]))]


def determinant(a):
    """Determinant of a square matrix using cofactor expansion (recursive)."""
    n = len(a)
    if n != len(a[0]):
        raise ValueError("Matrix must be square")
    if n == 1:
        return a[0][0]
    if n == 2:
        return a[0][0] * a[1][1] - a[0][1] * a[1][0]
    det = 0
    for col in range(n):
        # minor: remove row 0 and column `col`
        minor = [row[:col] + row[col + 1:] for row in a[1:]]
        det += ((-1) ** col) * a[0][col] * determinant(minor)
    return det


def show(m):
    for row in m:
        print(*row)


def main():
    A = [[1, 2], [3, 4]]
    B = [[5, 6], [7, 8]]
    print("A + B:"); show(add(A, B))
    print("A x B:"); show(multiply(A, B))
    print("Transpose of A:"); show(transpose(A))
    print("det(A) =", determinant(A))
    print("det(3x3) =", determinant([[2, 0, 1], [1, 3, 2], [1, 1, 1]]))


if __name__ == "__main__":
    main()
