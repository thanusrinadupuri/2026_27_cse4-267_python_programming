# Case Study 9: Matrix Calculator

## Problem Statement
Perform matrix addition, multiplication, transpose and determinant on user-defined matrices, with size checks.

## Objectives
- Work with 2D lists and nested loops.
- Use list comprehensions.
- Apply recursion for determinants.

## Assumptions
- Matrices contain numbers and are rectangular.
- Determinant is defined only for square matrices.
- Size errors raise `ValueError`.

## Algorithm
1. Addition: check equal size; add matching elements.
2. Multiplication: check columns(A) = rows(B); result[i][j] = sum(A[i][k] * B[k][j]).
3. Transpose: element (i, j) moves to (j, i).
4. Determinant: base cases for 1x1 and 2x2; otherwise expand along the first row using minors with alternating signs.

## Pseudocode
```
FUNCTION multiply(A, B)
    IF cols(A) != rows(B) ERROR
    FOR i, j: result[i][j] = SUM over k of A[i][k] * B[k][j]

FUNCTION det(M)
    IF n = 1 RETURN M[0][0]
    IF n = 2 RETURN ad - bc
    total = 0
    FOR col = 0 TO n-1
        total += (-1)^col * M[0][col] * det(minor(M, 0, col))
    RETURN total
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[/Select operation and matrices/]
    B --> C{Operation}
    C -- Add --> D{Same size?}
    C -- Multiply --> E{cols A = rows B?}
    C -- Transpose --> F[Swap rows and columns]
    C -- Determinant --> G{Square?}
    D -- Yes --> H[Add elements]
    E -- Yes --> I[Row x column sums]
    G -- Yes --> J[Recursive cofactor expansion]
    D -- No --> X[Error]
    E -- No --> X
    G -- No --> X
    H --> Z[Print result]
    I --> Z
    F --> Z
    J --> Z
    X --> Y([End])
    Z --> Y
```

## Source Code
See [matrix.py](matrix.py).

## Test Cases
| # | Input | Expected Output |
|---|-------|-----------------|
| 1 | [[1,2],[3,4]] + [[5,6],[7,8]] | [[6,8],[10,12]] |
| 2 | [[1,2],[3,4]] x [[5,6],[7,8]] | [[19,22],[43,50]] |
| 3 | transpose [[1,2,3],[4,5,6]] | [[1,4],[2,5],[3,6]] |
| 4 | det [[1,2],[3,4]] | -2 |
| 5 | det [[2,0,1],[1,3,2],[1,1,1]] | 0 |
| 6 | add 2x2 with 3x3 | ValueError |
| 7 | multiply 2x3 by 2x3 | ValueError |

## Output Screenshots
_Add screenshot here: `screenshots/09_output.png`_

## Conclusion
Matrix operations are implemented from first principles with loops and recursion, which builds understanding of nested data structures.
