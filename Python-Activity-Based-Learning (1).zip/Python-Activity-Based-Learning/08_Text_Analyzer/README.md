# Case Study 8: Text File Analyzer

## Problem Statement
Read a text file (or typed text) and report word count, unique words, longest word, most frequent words and palindromic words.

## Objectives
- Practise file handling and exceptions.
- Use string methods and dictionaries.
- Sort data with custom keys.

## Assumptions
- Text is in English; words are separated by spaces.
- Case and punctuation are ignored.
- Palindromes must have at least 2 letters.

## Algorithm
1. Read the file (handle missing file) or take typed text.
2. Convert to lowercase, remove punctuation, split into words.
3. Count each word using a dictionary.
4. Sort by count (descending) to get top words.
5. Find words equal to their reverse.
6. Print all statistics.

## Pseudocode
```
READ text
words = SPLIT(REMOVE_PUNCTUATION(LOWER(text)))
FOR each w in words: freq[w] = freq[w] + 1
top = SORT freq by count descending, TAKE 3
FOR each w in words: IF len(w)>1 AND w = REVERSE(w) ADD to palindromes
PRINT total, unique, lines, longest, top, palindromes
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[/Enter file name or text/]
    B --> C{File found?}
    C -- No --> D[Print error] --> Z([End])
    C -- Yes --> E[Clean text and split into words]
    E --> F[Count frequencies]
    F --> G[Find top words, longest word, palindromes]
    G --> H[Print report]
    H --> Z
```

## Source Code
See [analyzer.py](analyzer.py).

## Test Cases
| # | Input | Expected Output |
|---|-------|-----------------|
| 1 | "Hello, hello world!" | words 3, unique 2, top [("hello",2),("world",1)] |
| 2 | "madam level noon" | palindromes ["level","madam","noon"] |
| 3 | "a b a" | palindromes [] (single letters ignored) |
| 4 | "" (empty) | words 0, longest "" |
| 5 | File name that does not exist | File not found |

## Output Screenshots
_Add screenshot here: `screenshots/08_output.png`_

## Conclusion
The analyzer shows how dictionaries, sorting and file handling work together to process real text data.
