"""Case Study 8: Text File Analyzer (word frequency, palindromes, statistics)."""
import string


def clean_words(text):
    """Lowercase the text, strip punctuation and return a list of words."""
    table = str.maketrans("", "", string.punctuation)
    return text.lower().translate(table).split()


def word_frequency(words):
    """Return a dictionary {word: count}."""
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    return freq


def top_words(freq, n=3):
    """Return the n most frequent words as (word, count) pairs."""
    return sorted(freq.items(), key=lambda p: (-p[1], p[0]))[:n]


def palindromes(words):
    """Return the unique palindromic words (length 2 or more)."""
    return sorted({w for w in words if len(w) > 1 and w == w[::-1]})


def analyse(text):
    words = clean_words(text)
    freq = word_frequency(words)
    return {
        "words": len(words),
        "unique": len(freq),
        "lines": len(text.splitlines()),
        "longest": max(words, key=len) if words else "",
        "top": top_words(freq),
        "palindromes": palindromes(words),
    }


def main():
    name = input("Enter file name (blank to type text): ")
    try:
        if name:
            with open(name) as f:
                text = f.read()
        else:
            text = input("Enter text: ")
    except FileNotFoundError:
        print("File not found")
        return
    for key, value in analyse(text).items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    main()
