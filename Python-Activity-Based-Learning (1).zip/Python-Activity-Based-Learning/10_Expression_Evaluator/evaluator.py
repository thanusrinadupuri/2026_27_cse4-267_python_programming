"""Case Study 10: Arithmetic Expression Evaluator using Stacks.
Converts infix (2+3*4) to postfix, then evaluates the postfix form."""

PRECEDENCE = {"+": 1, "-": 1, "*": 2, "/": 2, "^": 3}


def tokenize(expr):
    """Split an expression into numbers, operators and brackets."""
    tokens, number = [], ""
    for ch in expr:
        if ch.isdigit() or ch == ".":
            number += ch
        else:
            if number:
                tokens.append(number)
                number = ""
            if ch in PRECEDENCE or ch in "()":
                tokens.append(ch)
            elif ch != " ":
                raise ValueError(f"Invalid character: {ch}")
    if number:
        tokens.append(number)
    return tokens


def to_postfix(tokens):
    """Shunting-yard algorithm: infix tokens -> postfix list."""
    output, stack = [], []
    for t in tokens:
        if t not in PRECEDENCE and t not in "()":     # a number
            output.append(t)
        elif t in PRECEDENCE:
            # '^' is right-associative, others left-associative
            while (stack and stack[-1] in PRECEDENCE and
                   (PRECEDENCE[stack[-1]] > PRECEDENCE[t] or
                    (PRECEDENCE[stack[-1]] == PRECEDENCE[t] and t != "^"))):
                output.append(stack.pop())
            stack.append(t)
        elif t == "(":
            stack.append(t)
        else:                                          # ')'
            while stack and stack[-1] != "(":
                output.append(stack.pop())
            if not stack:
                raise ValueError("Mismatched brackets")
            stack.pop()                                # remove '('
    while stack:
        if stack[-1] == "(":
            raise ValueError("Mismatched brackets")
        output.append(stack.pop())
    return output


def eval_postfix(postfix):
    """Evaluate a postfix list using a stack."""
    stack = []
    for t in postfix:
        if t not in PRECEDENCE:
            stack.append(float(t))
        else:
            if len(stack) < 2:
                raise ValueError("Invalid expression")
            b, a = stack.pop(), stack.pop()
            if t == "+": stack.append(a + b)
            elif t == "-": stack.append(a - b)
            elif t == "*": stack.append(a * b)
            elif t == "/":
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                stack.append(a / b)
            elif t == "^": stack.append(a ** b)
    if len(stack) != 1:
        raise ValueError("Invalid expression")
    return stack[0]


def evaluate(expr):
    return eval_postfix(to_postfix(tokenize(expr)))


def main():
    expr = input("Enter expression: ")
    try:
        print("Postfix:", " ".join(to_postfix(tokenize(expr))))
        print("Result :", evaluate(expr))
    except (ValueError, ZeroDivisionError) as err:
        print("Error:", err)


if __name__ == "__main__":
    main()
