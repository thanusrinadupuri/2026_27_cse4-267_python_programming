# Case Study 10: Arithmetic Expression Evaluator using Stacks

## Problem Statement
Evaluate expressions such as `2 + 3 * (4 - 1) ^ 2` correctly, respecting operator precedence, brackets and errors, without using Python's `eval()`.

## Objectives
- Implement a stack using lists.
- Convert infix to postfix (Shunting-yard).
- Evaluate postfix using a stack.
- Handle invalid input safely.

## Assumptions
- Supported operators: + - * / ^ and brackets.
- Numbers are non-negative (no unary minus).
- `^` is right-associative; others are left-associative.

## Algorithm
1. Tokenize the string into numbers, operators and brackets.
2. Infix to postfix: numbers go to output; operators pop higher/equal precedence operators first; "(" is pushed; ")" pops until "(".
3. Pop remaining operators to output.
4. Evaluate: push numbers; for an operator pop two values, compute, push result.
5. The last remaining value is the answer.

## Pseudocode
```
FUNCTION to_postfix(tokens)
    FOR each t
        IF number: output.add(t)
        ELSE IF operator:
            WHILE stack.top has higher/equal precedence: output.add(stack.pop())
            stack.push(t)
        ELSE IF "(": stack.push(t)
        ELSE ")": POP to output until "("
    POP remaining operators to output

FUNCTION eval_postfix(p)
    FOR each t: IF number push
                ELSE b = pop, a = pop, push(a OP b)
    RETURN pop
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[/Enter expression/]
    B --> C[Tokenize]
    C --> D[Infix to postfix with operator stack]
    D --> E{Brackets matched?}
    E -- No --> X[Error]
    E -- Yes --> F[Evaluate postfix with value stack]
    F --> G{Division by zero or bad form?}
    G -- Yes --> X
    G -- No --> H[Print result]
    X --> Z([End])
    H --> Z
```

## Source Code
See [evaluator.py](evaluator.py).

## Test Cases
| # | Input | Expected Output |
|---|-------|-----------------|
| 1 | 2+3*4 | 14.0 |
| 2 | (2+3)*4 | 20.0 |
| 3 | 10/4 | 2.5 |
| 4 | 2^3^2 | 512.0 |
| 5 | 10/(5-5) | Error: Division by zero |
| 6 | (2+3 | Error: Mismatched brackets |
| 7 | 2 $ 3 | Error: Invalid character: $ |
| 8 | 2+3*(4-1)^2 | 29.0 |

## Output Screenshots
_Add screenshot here: `screenshots/10_output.png`_

## Conclusion
Stacks make precedence and brackets easy to handle. The program shows a classic data-structure application and safe error handling.
