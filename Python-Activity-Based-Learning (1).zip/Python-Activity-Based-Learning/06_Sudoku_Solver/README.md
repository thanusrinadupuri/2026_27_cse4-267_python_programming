# Case Study 6: Sudoku Solver using Backtracking

## Problem Statement
Solve a 9x9 Sudoku puzzle where every row, column and 3x3 box must contain the digits 1-9 exactly once.

## Objectives
- Represent a grid with a 2D list.
- Apply recursion and backtracking.
- Validate moves against row, column and box rules.

## Assumptions
- Empty cells are marked 0.
- The input puzzle is valid (no initial conflicts).
- If the puzzle has several solutions, the first one found is shown.

## Algorithm
1. Find the first empty cell.
2. If none, the puzzle is solved.
3. Try digits 1-9; for each valid digit, place it and recurse.
4. If the recursion fails, reset the cell to 0 (backtrack) and try the next digit.
5. If no digit works, return failure to the previous cell.

## Pseudocode
```
FUNCTION solve(board)
    FIND empty cell (r, c)
    IF none RETURN True
    FOR num = 1 TO 9
        IF is_valid(board, r, c, num)
            board[r][c] = num
            IF solve(board) RETURN True
            board[r][c] = 0
    RETURN False
```

## Flowchart
```mermaid
flowchart TD
    A([Start solve]) --> B{Empty cell exists?}
    B -- No --> C([Return True: solved])
    B -- Yes --> D[num = 1]
    D --> E{num <= 9?}
    E -- No --> F([Return False: backtrack])
    E -- Yes --> G{Valid in row, column, box?}
    G -- No --> H[num = num + 1]
    H --> E
    G -- Yes --> I[Place num and call solve]
    I --> J{Returned True?}
    J -- Yes --> C
    J -- No --> K[Reset cell to 0]
    K --> H
```

## Source Code
See [sudoku.py](sudoku.py).

## Test Cases
| # | Input | Expected Output |
|---|-------|-----------------|
| 1 | Sample puzzle in main() | Solved grid; first row 5 3 4 6 7 8 9 1 2 |
| 2 | is_valid(board, 0, 2, 5) on sample | False (5 already in row) |
| 3 | is_valid(board, 0, 2, 4) on sample | True |
| 4 | Already solved board | True, board unchanged |
| 5 | Board with two 1s in a row and a blank forcing conflict | False / "No solution exists" |

## Output Screenshots
_Add screenshot here: `screenshots/06_output.png`_

## Conclusion
Backtracking systematically tries options and undoes wrong choices. The solver is short, correct and shows how recursion handles constraint problems.
