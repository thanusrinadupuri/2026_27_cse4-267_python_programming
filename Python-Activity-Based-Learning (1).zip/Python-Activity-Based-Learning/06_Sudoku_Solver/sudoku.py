"""Case Study 6: Sudoku Solver using Backtracking."""


def is_valid(board, row, col, num):
    """Check whether `num` can be placed at (row, col)."""
    for i in range(9):
        if board[row][i] == num or board[i][col] == num:
            return False
    # check the 3x3 box
    box_r, box_c = 3 * (row // 3), 3 * (col // 3)
    for r in range(box_r, box_r + 3):
        for c in range(box_c, box_c + 3):
            if board[r][c] == num:
                return False
    return True


def solve(board):
    """Solve the board in place. Returns True if a solution exists."""
    for row in range(9):
        for col in range(9):
            if board[row][col] == 0:            # empty cell found
                for num in range(1, 10):
                    if is_valid(board, row, col, num):
                        board[row][col] = num   # try it
                        if solve(board):
                            return True
                        board[row][col] = 0     # backtrack
                return False                    # no number fits here
    return True                                 # no empty cells left


def print_board(board):
    for r, row in enumerate(board):
        if r % 3 == 0 and r != 0:
            print("------+-------+------")
        line = ""
        for c, val in enumerate(row):
            if c % 3 == 0 and c != 0:
                line += "| "
            line += str(val) + " "
        print(line)


def main():
    board = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],
        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],
        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9],
    ]
    print("Puzzle:")
    print_board(board)
    if solve(board):
        print("\nSolution:")
        print_board(board)
    else:
        print("No solution exists")


if __name__ == "__main__":
    main()
