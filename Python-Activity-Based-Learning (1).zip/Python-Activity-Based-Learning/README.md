# Python Activity-Based Learning (ABL) Assignment

| Field | Details |
|-------|---------|
| **Name** | _Your Name_ |
| **Roll Number** | _Your Roll No_ |
| **Branch** | _Your Branch_ |
| **Section** | _Your Section_ |
| **Course** | Python Programming, I B.Tech., School of Computing and Intelligent Systems |

## Selected Case Studies
1. [Library Management System with Fine Calculation](01_Library_Management/)
2. [ATM Simulation with Limits and Mini Statement](02_ATM_Simulation/)
3. [Student Grade Analyzer](03_Student_Grade_Analyzer/)
4. [Unbeatable Tic-Tac-Toe using Minimax](04_TicTacToe_Minimax/)
5. [Inventory Management System with File Storage](05_Inventory_Management/)
6. [Sudoku Solver using Backtracking](06_Sudoku_Solver/)
7. [Banking System using OOP and Exception Handling](07_Banking_OOP/)
8. [Text File Analyzer](08_Text_Analyzer/)
9. [Matrix Calculator](09_Matrix_Calculator/)
10. [Arithmetic Expression Evaluator using Stacks](10_Expression_Evaluator/)

## Repository Structure
```
Python-Activity-Based-Learning/
├── README.md
├── report/ABL_Report.pdf      (consolidated report)
├── screenshots/               (output screenshots)
└── 01_.. to 10_..             (each: program .py + README.md with documentation)
```

## How to Run
```
cd 04_TicTacToe_Minimax
python tictactoe.py
```
Requires Python 3.8 or later. No external libraries are needed.
