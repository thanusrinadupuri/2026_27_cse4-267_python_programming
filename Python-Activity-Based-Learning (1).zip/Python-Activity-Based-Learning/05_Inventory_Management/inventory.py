"""Case Study 5: Inventory Management System with JSON file storage."""
import json
import os

FILE_NAME = "inventory.json"


def add_item(items, name, qty, price):
    """Add a new item or increase stock of an existing item."""
    if qty <= 0 or price < 0:
        return "Invalid quantity or price"
    if name in items:
        items[name]["qty"] += qty
    else:
        items[name] = {"qty": qty, "price": price}
    return "Item added"


def remove_stock(items, name, qty):
    """Reduce stock when items are sold."""
    if name not in items:
        return "Item not found"
    if qty > items[name]["qty"]:
        return "Not enough stock"
    items[name]["qty"] -= qty
    return "Stock updated"


def low_stock(items, limit=5):
    """Return names of items whose quantity is at or below the limit."""
    return [name for name, d in items.items() if d["qty"] <= limit]


def total_value(items):
    """Total money value of the stock."""
    return sum(d["qty"] * d["price"] for d in items.values())


def save(items):
    with open(FILE_NAME, "w") as f:
        json.dump(items, f, indent=2)


def load():
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME) as f:
            return json.load(f)
    return {}


def main():
    items = load()
    while True:
        print("\n1.Add 2.Sell 3.Low stock 4.Total value 5.Save & Exit")
        ch = input("Choice: ")
        if ch == "1":
            print(add_item(items, input("Name: "),
                           int(input("Qty: ")), float(input("Price: "))))
        elif ch == "2":
            print(remove_stock(items, input("Name: "), int(input("Qty: "))))
        elif ch == "3":
            print("Low stock:", low_stock(items))
        elif ch == "4":
            print("Total value: Rs.", total_value(items))
        elif ch == "5":
            save(items)
            print("Saved.")
            break


if __name__ == "__main__":
    main()
