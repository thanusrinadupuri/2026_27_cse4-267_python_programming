# Case Study 5: Inventory Management System with File Storage

## Problem Statement
A small shop needs to track item stock and prices, record sales, find items running low, and keep the data saved between runs.

## Objectives
- Use nested dictionaries for records.
- Read and write data using JSON files.
- Generate low-stock and total-value reports.

## Assumptions
- Item names are unique and case-sensitive.
- Low stock means quantity of 5 or less.
- Data is stored in `inventory.json` in the same folder.

## Algorithm
1. Load existing data from the JSON file (or start empty).
2. Show menu and read the choice.
3. Add: create item or increase quantity.
4. Sell: check item exists and stock is enough, then reduce.
5. Reports: list low-stock items, compute total value.
6. On exit, save data to the file.

## Pseudocode
```
items = LOAD file OR empty
LOOP
    READ choice
    Add : IF qty<=0 OR price<0 error
          ELSE IF name exists qty += q ELSE create record
    Sell: IF name missing "not found"
          ELSE IF q > qty "not enough" ELSE qty -= q
    Low : PRINT names WHERE qty <= 5
    Value: SUM(qty * price)
    Exit: SAVE items; STOP
END LOOP
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Load JSON file]
    B --> C[/Menu choice/]
    C --> D{Choice}
    D -- Add --> E[Add or update item]
    D -- Sell --> F{Item exists and stock enough?}
    F -- Yes --> G[Reduce stock]
    F -- No --> H[Show error]
    D -- Reports --> I[Low stock / total value]
    D -- Exit --> J[Save to JSON]
    J --> K([End])
    E --> C
    G --> C
    H --> C
    I --> C
```

## Source Code
See [inventory.py](inventory.py).

## Test Cases
| # | Input | Expected Output |
|---|-------|-----------------|
| 1 | add_item(items,"Pen",10,5) | Item added |
| 2 | total_value after test 1 | 50 |
| 3 | remove_stock(items,"Pen",3) | Stock updated (qty = 7) |
| 4 | remove_stock(items,"Pen",20) | Not enough stock |
| 5 | remove_stock(items,"Ink",1) | Item not found |
| 6 | add_item(items,"Pen",0,5) | Invalid quantity or price |
| 7 | low_stock with Pen qty 2 | ["Pen"] |

## Output Screenshots
_Add screenshot here: `screenshots/05_output.png`_

## Conclusion
The program shows how dictionaries and JSON files can be combined to build a small, persistent data-management application.
