"""Case Study 1: Library Management System with Fine Calculation."""

LOAN_DAYS = 7        # books can be kept free for 7 days
FINE_PER_DAY = 2     # Rs. 2 per extra day


def calculate_fine(days_kept):
    """Return the fine for keeping a book for `days_kept` days."""
    if days_kept <= LOAN_DAYS:
        return 0
    return (days_kept - LOAN_DAYS) * FINE_PER_DAY


def issue_book(library, book_id):
    """Issue a book if it exists and is available."""
    if book_id not in library:
        return "Book not found"
    if not library[book_id]["available"]:
        return "Book already issued"
    library[book_id]["available"] = False
    return "Book issued"


def return_book(library, book_id, days_kept):
    """Return a book and report the fine (if any)."""
    if book_id not in library:
        return "Book not found"
    if library[book_id]["available"]:
        return "Book was not issued"
    library[book_id]["available"] = True
    return f"Book returned. Fine: Rs.{calculate_fine(days_kept)}"


def show_books(library):
    """Print all books and their status."""
    for book_id, info in library.items():
        status = "Available" if info["available"] else "Issued"
        print(f"{book_id} | {info['title']:<20} | {status}")


def main():
    library = {
        101: {"title": "Python Basics", "available": True},
        102: {"title": "Data Structures", "available": True},
        103: {"title": "Algorithms", "available": True},
    }
    while True:
        print("\n1.Show  2.Issue  3.Return  4.Exit")
        choice = input("Enter choice: ")
        if choice == "1":
            show_books(library)
        elif choice == "2":
            print(issue_book(library, int(input("Book ID: "))))
        elif choice == "3":
            book_id = int(input("Book ID: "))
            days = int(input("Days kept: "))
            print(return_book(library, book_id, days))
        elif choice == "4":
            print("Goodbye!")
            break
        else:
            print("Invalid choice")


if __name__ == "__main__":
    main()
