# Case Study 1: Library Management System with Fine Calculation

## Problem Statement
A college library issues books to students and wants a program that tracks which books are available, issues and returns books, and calculates a late fine automatically.

## Objectives
- Store book records using a dictionary.
- Issue and return books with validation.
- Calculate fine for late returns.
- Use functions and a menu-driven loop.

## Assumptions
- Book IDs are unique integers.
- A book can be kept free for 7 days; fine is Rs. 2 per extra day.
- Only one copy of each book exists.
- Data is kept in memory (not saved after exit).

## Algorithm
1. Create the library dictionary (id -> title, available).
2. Show a menu and read the choice.
3. Issue: if the book exists and is available, mark it issued.
4. Return: if the book is issued, mark it available and compute the fine.
5. Repeat until the user chooses Exit.

## Pseudocode
```
LOAD library
LOOP
    DISPLAY menu, READ choice
    IF choice = Issue
        IF id not in library: PRINT "not found"
        ELSE IF book not available: PRINT "already issued"
        ELSE mark issued
    IF choice = Return
        IF book is issued: mark available
            fine = MAX(0, (days - 7) * 2); PRINT fine
    IF choice = Exit: STOP
END LOOP
```

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Load books]
    B --> C[/Show menu, read choice/]
    C --> D{Choice?}
    D -- Issue --> E{Book available?}
    E -- Yes --> F[Mark issued]
    E -- No --> G[Print error]
    D -- Return --> H[Mark available, calculate fine]
    D -- Show --> I[Print all books]
    D -- Exit --> J([End])
    F --> C
    G --> C
    H --> C
    I --> C
```

## Source Code
See [library.py](library.py).

## Test Cases
| # | Input | Expected Output |
|---|-------|-----------------|
| 1 | calculate_fine(5) | 0 |
| 2 | calculate_fine(7) | 0 |
| 3 | calculate_fine(10) | 6 |
| 4 | calculate_fine(20) | 26 |
| 5 | issue_book(101) | Book issued |
| 6 | issue_book(101) again | Book already issued |
| 7 | issue_book(999) | Book not found |
| 8 | return_book(101, 10) | Book returned. Fine: Rs.6 |

## Output Screenshots
_Add screenshot here: `screenshots/01_output.png`_

## Conclusion
The program manages issue and return of books and calculates fines correctly using dictionaries, functions and conditions. It can be extended with file storage and student records.
